import React from 'react';
import ReactDOM from 'react-dom/client';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import { ThemeProvider } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import theme from './theme';
import axios from 'axios';

// Import des composants
import App from './App';
import Login from './components/Login';
import Register from './components/Register';
import Dashboard from './components/Dashboard';
import ExamForm from './components/ExamForm';
import ExamList from './components/ExamList';
import StudentExams from './components/StudentExams';
import StudentResults from './components/StudentResults';

console.log('Starting application...');

// Configuration d'axios
axios.defaults.baseURL = 'http://localhost:5001';
// Ajouter l'intercepteur pour le token
axios.interceptors.request.use(
    (config) => {
        const token = localStorage.getItem('token');
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

// Configuration des routes
const router = createBrowserRouter([
    {
        path: '/',
        element: <App />,
        children: [
            {
                path: '/login',
                element: <Login />
            },
            {
                path: '/register',
                element: <Register />
            },
            {
                path: '/dashboard',
                element: <Dashboard />
            },
            {
                path: '/exam/new',
                element: <ExamForm />
            },
            {
                path: '/exams',
                element: <ExamList />
            },
            {
                path: '/student/exams',
                element: <StudentExams />
            },
            {
                path: '/student/results',
                element: <StudentResults />
            }
        ]
    }
]);

const root = ReactDOM.createRoot(document.getElementById('root'));
console.log('Root element found:', document.getElementById('root'));

root.render(
    <React.StrictMode>
        <ThemeProvider theme={theme}>
            <CssBaseline />
            <RouterProvider router={router} />
        </ThemeProvider>
    </React.StrictMode>
);

console.log('Application rendered');
