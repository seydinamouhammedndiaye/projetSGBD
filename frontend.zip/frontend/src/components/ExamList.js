import React, { useState, useEffect } from 'react';
import {
    Box,
    Typography,
    Container,
    Paper,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Button,
    Alert,
    Chip,
    CircularProgress,
    Stack
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import VisibilityIcon from '@mui/icons-material/Visibility';

const ExamList = () => {
    const navigate = useNavigate();
    const [exams, setExams] = useState([]);
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        fetchExams();
    }, []);

    const fetchExams = async () => {
        try {
            const token = localStorage.getItem('token');
            if (!token) {
                setError('Vous devez être connecté pour voir les épreuves');
                navigate('/login');
                return;
            }

            console.log('Récupération des épreuves...');
            const response = await axios.get(
                'http://localhost:5001/api/exams',
                {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                }
            );

            console.log('Réponse du serveur:', response.data);
            setExams(response.data);
            setError('');
        } catch (err) {
            console.error('Erreur complète:', err);
            const errorMessage = err.response?.data?.message || 'Erreur lors du chargement des épreuves';
            setError(errorMessage);
            if (err.response?.status === 401) {
                navigate('/login');
            }
        } finally {
            setLoading(false);
        }
    };

    const handleStartExam = (examId) => {
        navigate(`/exam/${examId}`);
    };

    const handleDownloadPDF = async (examId) => {
        try {
            const token = localStorage.getItem('token');
            const response = await axios.get(
                `http://localhost:5001/api/exams/${examId}/pdf`,
                {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    },
                    responseType: 'blob'
                }
            );
            
            const url = window.URL.createObjectURL(new Blob([response.data]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', 'exam.pdf');
            document.body.appendChild(link);
            link.click();
            link.remove();
            window.URL.revokeObjectURL(url);
        } catch (err) {
            console.error('Erreur lors du téléchargement:', err);
            setError('Erreur lors du téléchargement du PDF');
        }
    };

    const formatDate = (dateString) => {
        return new Date(dateString).toLocaleString('fr-FR', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    if (loading) {
        return (
            <Container sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '60vh' }}>
                <CircularProgress />
            </Container>
        );
    }

    return (
        <Container maxWidth="lg">
            <Paper sx={{ p: 4, mt: 4 }}>
                <Typography variant="h4" component="h1" gutterBottom align="center">
                    Liste des épreuves
                </Typography>

                {error && (
                    <Alert severity="error" sx={{ mb: 2 }}>
                        {error}
                    </Alert>
                )}

                {exams.length === 0 && !error ? (
                    <Alert severity="info" sx={{ mb: 2 }}>
                        Aucune épreuve disponible pour le moment.
                    </Alert>
                ) : (
                    <TableContainer>
                        <Table>
                            <TableHead>
                                <TableRow>
                                    <TableCell>Titre</TableCell>
                                    <TableCell>Matière</TableCell>
                                    <TableCell>Classe</TableCell>
                                    <TableCell>Date de début</TableCell>
                                    <TableCell>Date de fin</TableCell>
                                    <TableCell>Durée</TableCell>
                                    <TableCell>Statut</TableCell>
                                    <TableCell>Actions</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {exams.map((exam) => (
                                    <TableRow key={exam._id}>
                                        <TableCell>{exam.titre}</TableCell>
                                        <TableCell>{exam.matiere}</TableCell>
                                        <TableCell>{exam.classe}</TableCell>
                                        <TableCell>{formatDate(exam.dateDebut)}</TableCell>
                                        <TableCell>{formatDate(exam.dateFin)}</TableCell>
                                        <TableCell>{exam.duree} minutes</TableCell>
                                        <TableCell>
                                            <Chip
                                                label={exam.statut}
                                                color={exam.statut === 'planifie' ? 'primary' : 'default'}
                                            />
                                        </TableCell>
                                        <TableCell>
                                            <Stack direction="row" spacing={1}>
                                                <Button
                                                    variant="contained"
                                                    color="primary"
                                                    onClick={() => handleStartExam(exam._id)}
                                                    disabled={exam.statut === 'termine'}
                                                    startIcon={<VisibilityIcon />}
                                                >
                                                    Voir
                                                </Button>
                                                {exam.fichier && (
                                                    <Button
                                                        variant="outlined"
                                                        color="secondary"
                                                        onClick={() => handleDownloadPDF(exam._id)}
                                                        startIcon={<FileDownloadIcon />}
                                                    >
                                                        PDF
                                                    </Button>
                                                )}
                                            </Stack>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                )}
            </Paper>
        </Container>
    );
};

export default ExamList; 