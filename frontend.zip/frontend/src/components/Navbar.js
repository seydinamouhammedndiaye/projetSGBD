import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
    AppBar,
    Toolbar,
    Typography,
    Button,
    Box,
    IconButton,
    Menu,
    MenuItem,
} from '@mui/material';
import { AccountCircle } from '@mui/icons-material';

const Navbar = () => {
    const navigate = useNavigate();
    const [anchorEl, setAnchorEl] = React.useState(null);
    const user = JSON.parse(localStorage.getItem('user'));

    const handleMenu = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    const handleLogout = () => {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        navigate('/login');
    };

    return (
        <AppBar position="static">
            <Toolbar>
                <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
                    Gestion des Examens
                </Typography>

                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    {user?.role === 'enseignant' ? (
                        <>
                            <Button
                                color="inherit"
                                onClick={() => navigate('/dashboard')}
                            >
                                Tableau de bord
                            </Button>
                            <Button
                                color="inherit"
                                onClick={() => navigate('/exam/new')}
                            >
                                Créer un examen
                            </Button>
                            <Button
                                color="inherit"
                                onClick={() => navigate('/exams')}
                            >
                                Mes examens
                            </Button>
                        </>
                    ) : (
                        <>
                            <Button
                                color="inherit"
                                onClick={() => navigate('/dashboard')}
                            >
                                Tableau de bord
                            </Button>
                            <Button
                                color="inherit"
                                onClick={() => navigate('/student/exams')}
                            >
                                Examens
                            </Button>
                            <Button
                                color="inherit"
                                onClick={() => navigate('/student/results')}
                            >
                                Résultats
                            </Button>
                        </>
                    )}

                    <IconButton
                        size="large"
                        aria-label="compte de l'utilisateur"
                        aria-controls="menu-appbar"
                        aria-haspopup="true"
                        onClick={handleMenu}
                        color="inherit"
                    >
                        <AccountCircle />
                    </IconButton>
                    <Menu
                        id="menu-appbar"
                        anchorEl={anchorEl}
                        anchorOrigin={{
                            vertical: 'top',
                            horizontal: 'right',
                        }}
                        keepMounted
                        transformOrigin={{
                            vertical: 'top',
                            horizontal: 'right',
                        }}
                        open={Boolean(anchorEl)}
                        onClose={handleClose}
                    >
                        <MenuItem disabled>
                            {user?.prenom} {user?.nom}
                        </MenuItem>
                        <MenuItem onClick={handleLogout}>Déconnexion</MenuItem>
                    </Menu>
                </Box>
            </Toolbar>
        </AppBar>
    );
};

export default Navbar; 