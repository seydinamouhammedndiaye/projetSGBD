import React, { useState, useEffect } from 'react';
import {
    Box,
    Container,
    Typography,
    Paper,
    Accordion,
    AccordionSummary,
    AccordionDetails,
    Button,
    Chip,
    Grid,
    Alert
} from '@mui/material';
import { ExpandMore, Assignment, CloudUpload } from '@mui/icons-material';
import axios from 'axios';
import SubmissionForm from './SubmissionForm';
import { useNavigate } from 'react-router-dom';

const StudentExams = () => {
    const navigate = useNavigate();
    const [exams, setExams] = useState([]);
    const [selectedExam, setSelectedExam] = useState(null);
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const token = localStorage.getItem('token');
        const user = JSON.parse(localStorage.getItem('user') || '{}');
        
        console.log('Token:', token ? 'Présent' : 'Absent');
        console.log('User:', user);
        
        if (!token) {
            navigate('/login');
            return;
        }
        
        if (!user.classe) {
            setError('Aucune classe assignée. Contactez votre administrateur.');
            setLoading(false);
            return;
        }
        
        fetchExams();
    }, [navigate]);

    const fetchExams = async () => {
        try {
            const token = localStorage.getItem('token');
            const user = JSON.parse(localStorage.getItem('user') || '{}');
            
            console.log('Tentative de récupération des examens...');
            console.log('URL:', 'http://localhost:5001/api/exams');
            console.log('Headers:', {
                'Authorization': `Bearer ${token}`
            });
            console.log('Classe de l\'étudiant:', user.classe);

            const response = await axios.get('http://localhost:5001/api/exams', {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });

            console.log('Réponse du serveur:', response);
            
            if (response.data && Array.isArray(response.data)) {
                const filteredExams = response.data.filter(exam => exam.classe === user.classe);
                console.log('Examens filtrés pour la classe:', filteredExams);
                setExams(filteredExams);
                setError('');
            } else {
                console.error('Format de réponse invalide:', response.data);
                setError('Format de réponse invalide du serveur');
            }
        } catch (err) {
            console.error('Erreur détaillée:', err);
            
            if (err.response) {
                // Erreur avec réponse du serveur
                console.error('Statut:', err.response.status);
                console.error('Données:', err.response.data);
                setError(`Erreur ${err.response.status}: ${err.response.data.message || 'Erreur serveur'}`);
            } else if (err.request) {
                // Erreur sans réponse du serveur
                console.error('Pas de réponse du serveur');
                setError('Le serveur ne répond pas. Vérifiez que le serveur est démarré.');
            } else {
                // Erreur de configuration de la requête
                console.error('Erreur de configuration:', err.message);
                setError(`Erreur de configuration: ${err.message}`);
            }
            
            if (err.response?.status === 401) {
                console.log('Redirection vers la page de connexion...');
                navigate('/login');
            }
        } finally {
            setLoading(false);
        }
    };

    const handleDownloadExam = async (examId) => {
        try {
            const token = localStorage.getItem('token');
            const response = await axios.get(`/api/exams/${examId}/pdf`, {
                headers: {
                    'Authorization': `Bearer ${token}`
                },
                responseType: 'blob'
            });
            const url = window.URL.createObjectURL(new Blob([response.data]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', 'examen.pdf');
            document.body.appendChild(link);
            link.click();
            link.remove();
        } catch (err) {
            setError('Erreur lors du téléchargement du PDF');
        }
    };

    const handleSubmissionComplete = () => {
        setSelectedExam(null);
        fetchExams(); // Rafraîchir la liste des examens
    };

    const getStatusChip = (exam) => {
        const now = new Date();
        const start = new Date(exam.dateDebut);
        const end = new Date(exam.dateFin);

        if (now < start) {
            return <Chip label="À venir" color="info" size="small" />;
        } else if (now > end) {
            return <Chip label="Terminé" color="error" size="small" />;
        } else {
            return <Chip label="En cours" color="success" size="small" />;
        }
    };

    if (loading) {
        return (
            <Container>
                <Typography>Chargement des examens...</Typography>
            </Container>
        );
    }

    return (
        <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
            <Typography variant="h4" gutterBottom>
                Mes Examens
            </Typography>

            {error && (
                <Alert severity="error" sx={{ mb: 2 }}>
                    {error}
                </Alert>
            )}

            {exams.length === 0 ? (
                <Paper sx={{ p: 3 }}>
                    <Typography>Aucun examen disponible pour le moment.</Typography>
                </Paper>
            ) : (
                exams.map((exam) => (
                    <Accordion 
                        key={exam._id}
                        expanded={selectedExam === exam._id}
                        onChange={() => setSelectedExam(selectedExam === exam._id ? null : exam._id)}
                    >
                        <AccordionSummary expandIcon={<ExpandMore />}>
                            <Grid container alignItems="center" spacing={2}>
                                <Grid item>
                                    <Assignment />
                                </Grid>
                                <Grid item xs>
                                    <Typography variant="h6">{exam.titre}</Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        {exam.matiere} - {new Date(exam.dateDebut).toLocaleDateString()}
                                    </Typography>
                                </Grid>
                                <Grid item>
                                    {getStatusChip(exam)}
                                </Grid>
                            </Grid>
                        </AccordionSummary>
                        <AccordionDetails>
                            <Box sx={{ mb: 2 }}>
                                <Typography variant="body1" paragraph>
                                    {exam.description}
                                </Typography>
                                <Typography variant="body2" color="text.secondary">
                                    Durée: {exam.duree} minutes
                                </Typography>
                                <Box sx={{ mt: 2, mb: 2 }}>
                                    <Button
                                        variant="outlined"
                                        startIcon={<CloudUpload />}
                                        onClick={() => handleDownloadExam(exam._id)}
                                        sx={{ mr: 2 }}
                                    >
                                        Télécharger le sujet
                                    </Button>
                                </Box>

                                <SubmissionForm 
                                    examId={exam._id}
                                    onSubmissionComplete={handleSubmissionComplete}
                                />
                            </Box>
                        </AccordionDetails>
                    </Accordion>
                ))
            )}
        </Container>
    );
};

export default StudentExams; 