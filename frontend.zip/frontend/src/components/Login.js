import React, { useState, useEffect } from 'react';
import { Box, TextField, Button, Typography, Container, Paper, Alert } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const Login = () => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        email: '',
        password: ''
    });
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    useEffect(() => {
        // Vérifier s'il y a un message de succès d'inscription
        const registerSuccess = localStorage.getItem('registerSuccess');
        if (registerSuccess) {
            setSuccess(registerSuccess);
            localStorage.removeItem('registerSuccess');
        }
    }, []);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setSuccess('');
        
        try {
            const response = await axios.post(`${process.env.REACT_APP_API_URL}/auth/login`, formData);
            // Stocker le token dans le localStorage
            localStorage.setItem('token', response.data.token);
            // Stocker les informations de l'utilisateur
            localStorage.setItem('user', JSON.stringify(response.data.user));
            
            // Rediriger vers le tableau de bord
            navigate('/dashboard');
        } catch (err) {
            const errorMessage = err.response?.data?.message || 'Une erreur est survenue lors de la connexion';
            setError(errorMessage);
            console.error('Erreur de connexion:', errorMessage);
        }
    };

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    return (
        <Container maxWidth="sm">
            <Paper sx={{ p: 4, mt: 8 }}>
                <Typography variant="h4" component="h1" gutterBottom align="center">
                    Connexion
                </Typography>
                
                {error && (
                    <Alert severity="error" sx={{ mb: 2 }}>
                        {error}
                    </Alert>
                )}
                
                {success && (
                    <Alert severity="success" sx={{ mb: 2 }}>
                        {success}
                    </Alert>
                )}

                <Box component="form" onSubmit={handleSubmit} sx={{ mt: 2 }}>
                    <TextField
                        fullWidth
                        label="Email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleChange}
                        margin="normal"
                        required
                    />
                    <TextField
                        fullWidth
                        label="Mot de passe"
                        name="password"
                        type="password"
                        value={formData.password}
                        onChange={handleChange}
                        margin="normal"
                        required
                    />
                    <Button
                        type="submit"
                        fullWidth
                        variant="contained"
                        color="primary"
                        sx={{ mt: 3 }}
                    >
                        Se connecter
                    </Button>
                </Box>
            </Paper>
        </Container>
    );
};

export default Login; 