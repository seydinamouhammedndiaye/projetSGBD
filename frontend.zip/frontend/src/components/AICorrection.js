import React, { useState } from 'react';
import {
    Box,
    Card,
    CardContent,
    Typography,
    Button,
    TextField,
    CircularProgress,
    Alert,
    Paper
} from '@mui/material';
import axios from 'axios';

const AICorrection = ({ submission, onCorrectionComplete }) => {
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const [result, setResult] = useState(null);
    const [criteria, setCriteria] = useState('');

    const handleCorrection = async () => {
        try {
            setLoading(true);
            setError(null);
            
            const response = await axios.post('/api/submissions/correct', {
                submissionId: submission._id,
                contenuDevoir: submission.contenu,
                critereCorrection: criteria || 'Évaluer la qualité technique, la clarté et la pertinence de la réponse.'
            });

            if (response.data.success) {
                setResult(response.data);
                if (onCorrectionComplete) {
                    onCorrectionComplete(response.data);
                }
            } else {
                setError('La correction n\'a pas pu être effectuée.');
            }
        } catch (err) {
            setError(err.response?.data?.message || 'Une erreur est survenue lors de la correction.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <Card sx={{ mt: 2 }}>
            <CardContent>
                <Typography variant="h6" gutterBottom>
                    Correction IA
                </Typography>

                <TextField
                    fullWidth
                    multiline
                    rows={3}
                    variant="outlined"
                    label="Critères de correction (optionnel)"
                    value={criteria}
                    onChange={(e) => setCriteria(e.target.value)}
                    margin="normal"
                    placeholder="Entrez des critères spécifiques pour la correction..."
                />

                {error && (
                    <Alert severity="error" sx={{ mt: 2 }}>
                        {error}
                    </Alert>
                )}

                {loading ? (
                    <Box display="flex" justifyContent="center" mt={2}>
                        <CircularProgress />
                    </Box>
                ) : (
                    <Button
                        variant="contained"
                        color="primary"
                        onClick={handleCorrection}
                        sx={{ mt: 2 }}
                    >
                        Lancer la correction IA
                    </Button>
                )}

                {result && (
                    <Paper elevation={3} sx={{ mt: 2, p: 2 }}>
                        <Typography variant="h6" gutterBottom>
                            Résultat de la correction
                        </Typography>
                        <Typography variant="body1" gutterBottom>
                            <strong>Note :</strong> {result.note}/20
                        </Typography>
                        <Typography variant="body1" gutterBottom>
                            <strong>Commentaires :</strong>
                        </Typography>
                        <Typography variant="body2" style={{ whiteSpace: 'pre-line' }}>
                            {result.commentaires}
                        </Typography>
                    </Paper>
                )}
            </CardContent>
        </Card>
    );
};

export default AICorrection; 