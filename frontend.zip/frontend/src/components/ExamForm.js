import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
    Box,
    TextField,
    Button,
    Typography,
    Container,
    Paper,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Alert,
    Grid
} from '@mui/material';
import { CloudUpload } from '@mui/icons-material';
import axios from 'axios';

const ExamForm = () => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        titre: '',
        matiere: '',
        classe: '',
        duree: '',
        date: '',
        description: '',
        questions: []
    });
    const [file, setFile] = useState(null);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    useEffect(() => {
        // Vérifier si l'utilisateur est connecté et est un enseignant
        const token = localStorage.getItem('token');
        const user = JSON.parse(localStorage.getItem('user') || '{}');
        
        if (!token) {
            navigate('/login');
            return;
        }

        if (user.role !== 'enseignant') {
            navigate('/dashboard');
            setError('Accès non autorisé. Seuls les enseignants peuvent créer des épreuves.');
        }
    }, [navigate]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setSuccess('');

        try {
            const token = localStorage.getItem('token');
            const user = JSON.parse(localStorage.getItem('user') || '{}');
            
            if (!token) {
                setError('Vous devez être connecté pour créer une épreuve');
                navigate('/login');
                return;
            }

            if (user.role !== 'enseignant') {
                setError('Seuls les enseignants peuvent créer des épreuves');
                return;
            }

            if (!file) {
                setError('Veuillez sélectionner un fichier PDF');
                return;
            }

            const formDataToSend = new FormData();

            // Ajouter les données du formulaire
            Object.keys(formData).forEach(key => {
                if (formData[key]) {
                    formDataToSend.append(key, formData[key]);
                }
            });

            // Ajouter le fichier PDF
            formDataToSend.append('pdfFile', file);

            console.log('Token:', token);
            console.log('FormData keys:', [...formDataToSend.keys()]);

            const response = await axios.post(
                'http://localhost:5001/api/exams',
                formDataToSend,
                {
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'multipart/form-data'
                    }
                }
            );
            
            console.log('Réponse du serveur:', response.data);
            
            setSuccess('Épreuve créée avec succès !');
            setFormData({
                titre: '',
                matiere: '',
                classe: '',
                duree: '',
                date: '',
                description: '',
                questions: []
            });
            setFile(null);
            
            // Rediriger vers la liste des examens après un court délai
            setTimeout(() => {
                navigate('/exams');
            }, 2000);
        } catch (err) {
            console.error('Erreur complète:', err);
            const errorMessage = err.response?.data?.message || 'Une erreur est survenue lors de la création de l\'épreuve';
            setError(errorMessage);
            console.error('Message d\'erreur:', errorMessage);
        }
    };

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    const handleFileChange = (e) => {
        const selectedFile = e.target.files[0];
        if (selectedFile && selectedFile.type === 'application/pdf') {
            setFile(selectedFile);
        } else {
            setError('Veuillez sélectionner un fichier PDF valide');
            setFile(null);
        }
    };

    return (
        <Container maxWidth="md">
            <Paper sx={{ p: 4, mt: 4 }}>
                <Typography variant="h4" component="h1" gutterBottom align="center">
                    Créer une nouvelle épreuve
                </Typography>

                {error && (
                    <Alert severity="error" sx={{ mb: 2 }}>
                        {error}
                    </Alert>
                )}

                {success && (
                    <Alert severity="success" sx={{ mb: 2 }}>
                        {success}
                    </Alert>
                )}

                <Box component="form" onSubmit={handleSubmit} sx={{ mt: 2 }}>
                    <Grid container spacing={3}>
                        <Grid item xs={12}>
                            <TextField
                                fullWidth
                                label="Titre de l'épreuve"
                                name="titre"
                                value={formData.titre}
                                onChange={handleChange}
                                required
                            />
                        </Grid>

                        <Grid item xs={12} md={6}>
                            <TextField
                                fullWidth
                                label="Matière"
                                name="matiere"
                                value={formData.matiere}
                                onChange={handleChange}
                                required
                            />
                        </Grid>

                        <Grid item xs={12} md={6}>
                            <TextField
                                fullWidth
                                label="Classe"
                                name="classe"
                                value={formData.classe}
                                onChange={handleChange}
                                required
                            />
                        </Grid>

                        <Grid item xs={12} md={6}>
                            <TextField
                                fullWidth
                                label="Durée (en minutes)"
                                name="duree"
                                type="number"
                                value={formData.duree}
                                onChange={handleChange}
                                required
                            />
                        </Grid>

                        <Grid item xs={12} md={6}>
                            <TextField
                                fullWidth
                                label="Date de l'épreuve"
                                name="date"
                                type="datetime-local"
                                value={formData.date}
                                onChange={handleChange}
                                required
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </Grid>

                        <Grid item xs={12}>
                            <TextField
                                fullWidth
                                label="Description"
                                name="description"
                                multiline
                                rows={4}
                                value={formData.description}
                                onChange={handleChange}
                                required
                            />
                        </Grid>

                        <Grid item xs={12}>
                            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                                <Button
                                    component="label"
                                    variant="outlined"
                                    startIcon={<CloudUpload />}
                                >
                                    Télécharger le PDF
                                    <input
                                        type="file"
                                        hidden
                                        accept=".pdf"
                                        onChange={handleFileChange}
                                    />
                                </Button>
                                {file && (
                                    <Typography variant="body2" color="text.secondary">
                                        {file.name}
                                    </Typography>
                                )}
                            </Box>
                        </Grid>

                        <Grid item xs={12}>
                            <Button
                                type="submit"
                                fullWidth
                                variant="contained"
                                color="primary"
                                size="large"
                            >
                                Créer l'épreuve
                            </Button>
                        </Grid>
                    </Grid>
                </Box>
            </Paper>
        </Container>
    );
};

export default ExamForm; 