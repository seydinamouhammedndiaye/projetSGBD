import React, { useState, useEffect } from 'react';
import {
    Box,
    Typography,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Paper,
    CircularProgress,
    Alert
} from '@mui/material';
import axios from 'axios';

const StudentResults = () => {
    const [results, setResults] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        fetchResults();
    }, []);

    const fetchResults = async () => {
        try {
            const response = await axios.get('/api/submissions/student');
            setResults(response.data);
            setLoading(false);
        } catch (err) {
            setError('Erreur lors du chargement des résultats');
            setLoading(false);
            console.error(err);
        }
    };

    const formatDate = (date) => {
        return new Date(date).toLocaleString('fr-FR');
    };

    if (loading) {
        return (
            <Box display="flex" justifyContent="center" m={3}>
                <CircularProgress />
            </Box>
        );
    }

    if (error) {
        return (
            <Alert severity="error" sx={{ m: 2 }}>
                {error}
            </Alert>
        );
    }

    return (
        <Box sx={{ mt: 3 }}>
            <Typography variant="h5" gutterBottom>
                Mes Résultats
            </Typography>

            <TableContainer component={Paper}>
                <Table>
                    <TableHead>
                        <TableRow>
                            <TableCell>Examen</TableCell>
                            <TableCell>Matière</TableCell>
                            <TableCell>Date de soumission</TableCell>
                            <TableCell>Statut</TableCell>
                            <TableCell>Note</TableCell>
                            <TableCell>Commentaires</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {results.map((result) => (
                            <TableRow key={result._id}>
                                <TableCell>{result.exam?.titre || 'N/A'}</TableCell>
                                <TableCell>{result.exam?.matiere || 'N/A'}</TableCell>
                                <TableCell>{formatDate(result.dateCreation)}</TableCell>
                                <TableCell>{result.statut}</TableCell>
                                <TableCell>
                                    {result.note ? `${result.note}/20` : 'En attente'}
                                </TableCell>
                                <TableCell>
                                    {result.commentaires || 'Aucun commentaire'}
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>

            {results.length === 0 && (
                <Typography variant="body1" sx={{ mt: 2, textAlign: 'center' }}>
                    Aucun résultat disponible
                </Typography>
            )}
        </Box>
    );
};

export default StudentResults; 