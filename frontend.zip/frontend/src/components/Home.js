import React, { useEffect } from 'react';
import { Box, Typography, Button, Container, Grid, Paper } from '@mui/material';
import { Link } from 'react-router-dom';

const Home = () => {
    useEffect(() => {
        console.log('Home component mounted');
    }, []);

    return (
        <Container maxWidth="lg">
            <Box sx={{ mt: 8, mb: 6, textAlign: 'center' }}>
                <Typography variant="h2" component="h1" gutterBottom>
                    Bienvenue sur la Plateforme de Gestion des Examens
                </Typography>
                <Typography variant="h5" component="h2" gutterBottom color="text.secondary">
                    Une solution moderne pour la gestion des examens en ligne
                </Typography>
            </Box>

            <Grid container spacing={4} sx={{ mt: 4 }}>
                <Grid item xs={12} md={4}>
                    <Paper sx={{ p: 3, textAlign: 'center', height: '100%' }}>
                        <Typography variant="h6" gutterBottom>
                            Pour les Étudiants
                        </Typography>
                        <Typography paragraph>
                            Accédez à vos examens, soumettez vos réponses et suivez vos résultats en temps réel.
                        </Typography>
                        <Button component={Link} to="/register" variant="contained" color="primary">
                            S'inscrire en tant qu'étudiant
                        </Button>
                    </Paper>
                </Grid>

                <Grid item xs={12} md={4}>
                    <Paper sx={{ p: 3, textAlign: 'center', height: '100%' }}>
                        <Typography variant="h6" gutterBottom>
                            Pour les Enseignants
                        </Typography>
                        <Typography paragraph>
                            Créez et gérez vos examens, corrigez les copies et suivez les progrès de vos étudiants.
                        </Typography>
                        <Button component={Link} to="/register" variant="contained" color="primary">
                            S'inscrire en tant qu'enseignant
                        </Button>
                    </Paper>
                </Grid>

                <Grid item xs={12} md={4}>
                    <Paper sx={{ p: 3, textAlign: 'center', height: '100%' }}>
                        <Typography variant="h6" gutterBottom>
                            Déjà un compte ?
                        </Typography>
                        <Typography paragraph>
                            Connectez-vous pour accéder à votre espace personnel.
                        </Typography>
                        <Button component={Link} to="/login" variant="contained" color="secondary">
                            Se connecter
                        </Button>
                    </Paper>
                </Grid>
            </Grid>
        </Container>
    );
};

export default Home; 