import React, { useEffect, useState } from 'react';
import {
    Box,
    Container,
    Grid,
    Typography,
    Button,
    Card,
    CardContent,
    CardActions
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { Assignment, Assessment } from '@mui/icons-material';
import SubmissionsDashboard from './SubmissionsDashboard';

const Dashboard = () => {
    const navigate = useNavigate();
    const [user, setUser] = useState(null);

    useEffect(() => {
        const userData = localStorage.getItem('user');
        if (userData) {
            setUser(JSON.parse(userData));
        }
    }, []);

    if (!user) {
        return (
            <Container>
                <Typography>Chargement...</Typography>
            </Container>
        );
    }

    return (
        <Container maxWidth="lg">
            <Box sx={{ mt: 4, mb: 4 }}>
                <Typography variant="h4" component="h1" gutterBottom>
                    Tableau de bord
                </Typography>
                <Typography variant="subtitle1" color="text.secondary">
                    Bienvenue, {user.prenom} {user.nom}
                </Typography>
            </Box>

            <Grid container spacing={3}>
                {user.role === 'enseignant' && (
                    <>
                        <Grid item xs={12} md={6}>
                            <Card>
                                <CardContent>
                                    <Typography variant="h6" gutterBottom>
                                        Créer une nouvelle épreuve
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        Créez une nouvelle épreuve pour vos étudiants
                                    </Typography>
                                </CardContent>
                                <CardActions>
                                    <Button
                                        size="small"
                                        color="primary"
                                        onClick={() => navigate('/exam/new')}
                                    >
                                        Créer une épreuve
                                    </Button>
                                </CardActions>
                            </Card>
                        </Grid>

                        <Grid item xs={12} md={6}>
                            <Card>
                                <CardContent>
                                    <Typography variant="h6" gutterBottom>
                                        Gérer les épreuves
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        Consultez et gérez vos épreuves existantes
                                    </Typography>
                                </CardContent>
                                <CardActions>
                                    <Button
                                        size="small"
                                        color="primary"
                                        onClick={() => navigate('/exams')}
                                    >
                                        Voir les épreuves
                                    </Button>
                                </CardActions>
                            </Card>
                        </Grid>
                    </>
                )}

                {user.role === 'etudiant' && (
                    <>
                        <Grid item xs={12} md={6}>
                            <Card>
                                <CardContent>
                                    <Typography variant="h6" gutterBottom>
                                        Mes épreuves
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        Consultez et soumettez vos devoirs pour les épreuves disponibles
                                    </Typography>
                                </CardContent>
                                <CardActions>
                                    <Button
                                        size="small"
                                        color="primary"
                                        startIcon={<Assignment />}
                                        onClick={() => navigate('/student/exams')}
                                    >
                                        Voir les épreuves
                                    </Button>
                                </CardActions>
                            </Card>
                        </Grid>

                        <Grid item xs={12} md={6}>
                            <Card>
                                <CardContent>
                                    <Typography variant="h6" gutterBottom>
                                        Mes résultats
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        Consultez vos résultats d'épreuves et les corrections
                                    </Typography>
                                </CardContent>
                                <CardActions>
                                    <Button
                                        size="small"
                                        color="primary"
                                        startIcon={<Assessment />}
                                        onClick={() => navigate('/student/results')}
                                    >
                                        Voir mes résultats
                                    </Button>
                                </CardActions>
                            </Card>
                        </Grid>
                    </>
                )}

                {/* Section des soumissions récentes */}
                <Grid item xs={12}>
                    <SubmissionsDashboard />
                </Grid>
            </Grid>
        </Container>
    );
};

export default Dashboard; 