import React, { useState } from 'react';
import {
    Box,
    Button,
    Paper,
    Typography,
    Alert,
    CircularProgress,
    Input,
    Stack
} from '@mui/material';
import { CloudUpload, Send } from '@mui/icons-material';
import axios from 'axios';

const SubmissionForm = ({ examId, onSubmissionComplete }) => {
    const [file, setFile] = useState(null);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    const handleFileChange = (event) => {
        const selectedFile = event.target.files[0];
        if (selectedFile) {
            if (selectedFile.size > 5 * 1024 * 1024) { // 5MB
                setError('Le fichier est trop volumineux. Taille maximale : 5MB');
                return;
            }
            if (!['application/pdf', 'text/plain'].includes(selectedFile.type)) {
                setError('Format de fichier non supporté. Utilisez PDF ou TXT');
                return;
            }
            setFile(selectedFile);
            setError('');
        }
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        if (!file) {
            setError('Veuillez sélectionner un fichier');
            return;
        }

        setLoading(true);
        setError('');
        setSuccess('');

        const formData = new FormData();
        formData.append('fichier', file);

        try {
            const token = localStorage.getItem('token');
            const response = await axios.post(`/api/submissions/${examId}`, formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                    'Authorization': `Bearer ${token}`
                }
            });

            setSuccess('Devoir soumis avec succès ! La correction automatique est en cours...');
            if (onSubmissionComplete) {
                onSubmissionComplete(response.data);
            }
            setFile(null);
        } catch (err) {
            console.error('Erreur lors de la soumission:', err);
            setError(err.response?.data?.message || 'Erreur lors de la soumission du devoir');
        } finally {
            setLoading(false);
        }
    };

    return (
        <Paper elevation={3} sx={{ p: 3, mb: 3, backgroundColor: '#f8f9fa' }}>
            <Typography variant="h6" gutterBottom color="primary">
                Soumettre votre devoir
            </Typography>

            <Box component="form" onSubmit={handleSubmit} sx={{ mt: 2 }}>
                <Stack spacing={2} alignItems="flex-start">
                    <Input
                        type="file"
                        onChange={handleFileChange}
                        sx={{ display: 'none' }}
                        id="file-input"
                        inputProps={{
                            accept: '.pdf,.txt'
                        }}
                    />
                    <label htmlFor="file-input">
                        <Button
                            variant="outlined"
                            component="span"
                            startIcon={<CloudUpload />}
                            color="primary"
                            sx={{ mb: 1 }}
                        >
                            Sélectionner un fichier
                        </Button>
                    </label>

                    {file && (
                        <Typography variant="body2" sx={{ mb: 1 }}>
                            Fichier sélectionné : {file.name}
                        </Typography>
                    )}

                    {error && (
                        <Alert severity="error" sx={{ mb: 1, width: '100%' }}>
                            {error}
                        </Alert>
                    )}

                    {success && (
                        <Alert severity="success" sx={{ mb: 1, width: '100%' }}>
                            {success}
                        </Alert>
                    )}

                    <Button
                        type="submit"
                        variant="contained"
                        color="primary"
                        disabled={!file || loading}
                        startIcon={loading ? <CircularProgress size={20} /> : <Send />}
                        sx={{ mt: 1 }}
                    >
                        {loading ? 'Soumission en cours...' : 'Soumettre le devoir'}
                    </Button>
                </Stack>
            </Box>
        </Paper>
    );
};

export default SubmissionForm; 