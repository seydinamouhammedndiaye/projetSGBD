import React, { useState, useEffect } from 'react';
import {
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Paper,
    Typography,
    Button,
    Box
} from '@mui/material';
import axios from 'axios';
import AICorrection from './AICorrection';

const SubmissionList = ({ examId }) => {
    const [submissions, setSubmissions] = useState([]);
    const [selectedSubmission, setSelectedSubmission] = useState(null);
    const [error, setError] = useState(null);

    useEffect(() => {
        fetchSubmissions();
    }, [examId]);

    const fetchSubmissions = async () => {
        try {
            const response = await axios.get(`/api/submissions/exam/${examId}`);
            setSubmissions(response.data);
        } catch (err) {
            setError('Erreur lors du chargement des soumissions');
            console.error(err);
        }
    };

    const handleCorrectionComplete = async (submissionId, correctionData) => {
        // Mettre à jour la liste des soumissions après la correction
        await fetchSubmissions();
        setSelectedSubmission(null);
    };

    const formatDate = (date) => {
        return new Date(date).toLocaleString();
    };

    return (
        <Box sx={{ mt: 3 }}>
            <Typography variant="h6" gutterBottom>
                Liste des soumissions
            </Typography>

            <TableContainer component={Paper}>
                <Table>
                    <TableHead>
                        <TableRow>
                            <TableCell>Étudiant</TableCell>
                            <TableCell>Date de soumission</TableCell>
                            <TableCell>Statut</TableCell>
                            <TableCell>Note</TableCell>
                            <TableCell>Actions</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {submissions.map((submission) => (
                            <React.Fragment key={submission._id}>
                                <TableRow>
                                    <TableCell>
                                        {submission.etudiant.prenom} {submission.etudiant.nom}
                                    </TableCell>
                                    <TableCell>{formatDate(submission.dateCreation)}</TableCell>
                                    <TableCell>{submission.statut}</TableCell>
                                    <TableCell>{submission.note ? `${submission.note}/20` : '-'}</TableCell>
                                    <TableCell>
                                        <Button
                                            variant="contained"
                                            color="primary"
                                            onClick={() => setSelectedSubmission(submission)}
                                            disabled={submission.statut === 'corrigé'}
                                        >
                                            Corriger avec l'IA
                                        </Button>
                                    </TableCell>
                                </TableRow>
                                {selectedSubmission && selectedSubmission._id === submission._id && (
                                    <TableRow>
                                        <TableCell colSpan={5}>
                                            <AICorrection
                                                submission={submission}
                                                onCorrectionComplete={(data) => handleCorrectionComplete(submission._id, data)}
                                            />
                                        </TableCell>
                                    </TableRow>
                                )}
                            </React.Fragment>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>

            {error && (
                <Typography color="error" sx={{ mt: 2 }}>
                    {error}
                </Typography>
            )}
        </Box>
    );
};

export default SubmissionList; 