import React, { useState, useEffect } from 'react';
import {
    Box,
    Card,
    CardContent,
    Typography,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Paper,
    Button,
    CircularProgress,
    Alert
} from '@mui/material';
import axios from 'axios';
import AICorrection from './AICorrection';

const SubmissionsDashboard = () => {
    const [submissions, setSubmissions] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [selectedSubmission, setSelectedSubmission] = useState(null);

    useEffect(() => {
        fetchSubmissions();
    }, []);

    const fetchSubmissions = async () => {
        try {
            const user = JSON.parse(localStorage.getItem('user'));
            const token = localStorage.getItem('token');
            
            let endpoint = user.role === 'enseignant' 
                ? '/api/submissions/teacher'
                : '/api/submissions/student';
            
            const response = await axios.get(endpoint, {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            
            setSubmissions(response.data);
            setLoading(false);
        } catch (err) {
            setError('Erreur lors du chargement des soumissions');
            setLoading(false);
            console.error(err);
        }
    };

    const handleCorrectionComplete = async (submissionId, correctionData) => {
        await fetchSubmissions();
        setSelectedSubmission(null);
    };

    const formatDate = (date) => {
        return new Date(date).toLocaleString('fr-FR');
    };

    if (loading) {
        return (
            <Box display="flex" justifyContent="center" m={3}>
                <CircularProgress />
            </Box>
        );
    }

    if (error) {
        return (
            <Alert severity="error" sx={{ m: 2 }}>
                {error}
            </Alert>
        );
    }

    return (
        <Card sx={{ mt: 3 }}>
            <CardContent>
                <Typography variant="h6" gutterBottom>
                    Soumissions récentes
                </Typography>

                <TableContainer component={Paper}>
                    <Table>
                        <TableHead>
                            <TableRow>
                                <TableCell>Examen</TableCell>
                                <TableCell>Étudiant</TableCell>
                                <TableCell>Date de soumission</TableCell>
                                <TableCell>Statut</TableCell>
                                <TableCell>Note</TableCell>
                                <TableCell>Actions</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {submissions.map((submission) => (
                                <React.Fragment key={submission._id}>
                                    <TableRow>
                                        <TableCell>{submission.exam?.titre || 'N/A'}</TableCell>
                                        <TableCell>
                                            {submission.etudiant?.prenom} {submission.etudiant?.nom}
                                        </TableCell>
                                        <TableCell>{formatDate(submission.dateCreation)}</TableCell>
                                        <TableCell>{submission.statut}</TableCell>
                                        <TableCell>{submission.note ? `${submission.note}/20` : '-'}</TableCell>
                                        <TableCell>
                                            <Button
                                                variant="contained"
                                                color="primary"
                                                size="small"
                                                onClick={() => setSelectedSubmission(submission)}
                                                disabled={submission.statut === 'corrigé'}
                                            >
                                                Corriger avec l'IA
                                            </Button>
                                        </TableCell>
                                    </TableRow>
                                    {selectedSubmission && selectedSubmission._id === submission._id && (
                                        <TableRow>
                                            <TableCell colSpan={6}>
                                                <AICorrection
                                                    submission={submission}
                                                    onCorrectionComplete={(data) => handleCorrectionComplete(submission._id, data)}
                                                />
                                            </TableCell>
                                        </TableRow>
                                    )}
                                </React.Fragment>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>

                {submissions.length === 0 && (
                    <Typography variant="body2" color="text.secondary" sx={{ mt: 2, textAlign: 'center' }}>
                        Aucune soumission trouvée
                    </Typography>
                )}
            </CardContent>
        </Card>
    );
};

export default SubmissionsDashboard; 