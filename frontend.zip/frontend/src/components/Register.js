import React, { useState } from 'react';
import { Box, TextField, Button, Typography, Container, Paper, FormControl, InputLabel, Select, MenuItem, Alert } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const Register = () => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        nom: '',
        prenom: '',
        email: '',
        password: '',
        role: 'etudiant',
        matiere: '',
        classe: ''
    });
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setSuccess('');
        
        try {
            await axios.post(`${process.env.REACT_APP_API_URL}/auth/register`, formData);
            setSuccess('Inscription réussie ! Vous allez être redirigé vers la page de connexion.');
            // Stocker le message de succès dans le localStorage pour l'afficher sur la page de connexion
            localStorage.setItem('registerSuccess', 'Inscription réussie ! Vous pouvez maintenant vous connecter.');
            setTimeout(() => {
                navigate('/login');
            }, 2000);
        } catch (err) {
            const errorMessage = err.response?.data?.message || 'Une erreur est survenue lors de l\'inscription';
            setError(errorMessage);
            console.error('Erreur d\'inscription:', errorMessage);
        }
    };

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    return (
        <Container maxWidth="sm">
            <Paper sx={{ p: 4, mt: 8 }}>
                <Typography variant="h4" component="h1" gutterBottom align="center">
                    Inscription
                </Typography>
                
                {error && (
                    <Alert severity="error" sx={{ mb: 2 }}>
                        {error}
                    </Alert>
                )}
                
                {success && (
                    <Alert severity="success" sx={{ mb: 2 }}>
                        {success}
                    </Alert>
                )}

                <Box component="form" onSubmit={handleSubmit} sx={{ mt: 2 }}>
                    <TextField
                        fullWidth
                        label="Nom"
                        name="nom"
                        value={formData.nom}
                        onChange={handleChange}
                        margin="normal"
                        required
                    />
                    <TextField
                        fullWidth
                        label="Prénom"
                        name="prenom"
                        value={formData.prenom}
                        onChange={handleChange}
                        margin="normal"
                        required
                    />
                    <TextField
                        fullWidth
                        label="Email"
                        name="email"
                        type="email"
                        value={formData.email}
                        onChange={handleChange}
                        margin="normal"
                        required
                    />
                    <TextField
                        fullWidth
                        label="Mot de passe"
                        name="password"
                        type="password"
                        value={formData.password}
                        onChange={handleChange}
                        margin="normal"
                        required
                    />
                    <FormControl fullWidth margin="normal">
                        <InputLabel>Rôle</InputLabel>
                        <Select
                            name="role"
                            value={formData.role}
                            onChange={handleChange}
                            label="Rôle"
                        >
                            <MenuItem value="etudiant">Étudiant</MenuItem>
                            <MenuItem value="enseignant">Enseignant</MenuItem>
                        </Select>
                    </FormControl>
                    
                    {formData.role === 'enseignant' && (
                        <TextField
                            fullWidth
                            label="Matière enseignée"
                            name="matiere"
                            value={formData.matiere}
                            onChange={handleChange}
                            margin="normal"
                            required
                        />
                    )}
                    
                    {formData.role === 'etudiant' && (
                        <TextField
                            fullWidth
                            label="Classe"
                            name="classe"
                            value={formData.classe}
                            onChange={handleChange}
                            margin="normal"
                            required
                        />
                    )}

                    <Button
                        type="submit"
                        fullWidth
                        variant="contained"
                        color="primary"
                        sx={{ mt: 3 }}
                    >
                        S'inscrire
                    </Button>
                </Box>
            </Paper>
        </Container>
    );
};

export default Register; 