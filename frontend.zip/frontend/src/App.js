import React from 'react';
import { Outlet, Navigate, useLocation } from 'react-router-dom';
import { Box, Container } from '@mui/material';
import Navbar from './components/Navbar';

const App = () => {
    const location = useLocation();
    const isAuthenticated = !!localStorage.getItem('token');

    // Si l'utilisateur n'est pas authentifié et n'est pas sur la page de login ou register
    if (!isAuthenticated && 
        !location.pathname.includes('/login') && 
        !location.pathname.includes('/register')) {
        return <Navigate to="/login" />;
    }

    // Si l'utilisateur est authentifié et est sur la page de login ou register
    if (isAuthenticated && 
        (location.pathname.includes('/login') || 
         location.pathname.includes('/register') ||
         location.pathname === '/')) {
        return <Navigate to="/dashboard" />;
    }

    return (
        <Box sx={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
            {isAuthenticated && <Navbar />}
            <Container component="main" sx={{ flexGrow: 1, py: 3 }}>
                <Outlet />
            </Container>
        </Box>
    );
};

export default App;
